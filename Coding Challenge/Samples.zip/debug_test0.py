﻿""" debug_test0.py """
def add(a, b):
    c = a + b
    return c

def main():
    x = 3
    y = 5
    z = add(x, y)
    print(z)

if __name__ == '__main__':
    main()
