print("import_test0 start")
print("__name__ = {}".format(__name__))
def main():
    print("main executed")
if __name__ == '__main__':
    main()
