// This file exists just to make sure the package is still defined
// when tests run on darwin/linux
package pkg
