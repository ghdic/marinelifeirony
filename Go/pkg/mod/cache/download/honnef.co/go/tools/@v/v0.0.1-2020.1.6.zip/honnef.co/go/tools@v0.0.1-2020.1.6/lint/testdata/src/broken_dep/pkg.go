package pkg

import _ "unknown_package"
