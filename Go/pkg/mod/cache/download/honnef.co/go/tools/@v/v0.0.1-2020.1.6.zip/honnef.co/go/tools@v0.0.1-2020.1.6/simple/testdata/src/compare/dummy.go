// This file exists just to make sure the package is still defined
// when tests DO NOT run on darwin/linux
package pkg
