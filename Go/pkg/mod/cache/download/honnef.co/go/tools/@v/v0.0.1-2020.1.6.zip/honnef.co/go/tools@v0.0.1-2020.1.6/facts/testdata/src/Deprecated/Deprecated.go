package pkg

// Deprecated: Don't use this.
func fn2() { // want fn2:`Deprecated: Don't use this\.`
}
